import React, {useState, useEffect} from 'react';

import { Link, useNavigate, useParams } from 'react-router-dom';
import EmployeeService from '../services/EmployeeService';

const AddEmployeeComponent =()=>{

    const [empId, setEmpId] = useState('')
    const [empName, setEmpName] = useState('')
    const [empAddress, setEmpAddress] = useState('')
    const [empContactNumber, setEmpContactNumber] = useState('')
    const [empSalary, setEmpSalary] = useState('')
    const [empDOB, setEmpDOB] = useState('')
    const [empEmailId, setEmpEmailId] = useState('')
    const [empPassword, setEmpPassword] = useState('')

    const history = useNavigate();
    const {employeeId} = useParams();

    const saveOrUpdateEmployee = (e)=>{
        e.preventDefault();

        const employee = {empId, empName, empAddress, empContactNumber, empSalary, empDOB, empEmailId, empPassword}

        if(employeeId){

            EmployeeService.updateEmployee(employeeId, employee).then((response)=>{
                history.push('/employees')
            }).catch(error=>{
                console.log(error);
            })

        }else{

            EmployeeService.createEmployee(employee).then((response)=>{
                console.log(response.data);
                history.push('/employees');
            }).catch(error=>{
                console.log(error);
            })

        }
    }

    useEffect(()=>{
        EmployeeService.getEmployeeById(employeeId).then((response)=>{
            setEmpId(response.data.empId);
            setEmpName(response.data.empName);
            setEmpAddress(response.data.empAddress);
            setEmpContactNumber(response.data.empContactNumber);
            setEmpSalary(response.data.empSalary);
            setEmpEmailId(response.data.empEmailId);
            setEmpPassword(response.data.empPassword);
        }).catch(error=>{
            console.log(error);
        })
    }, [])

    const title =()=>{
        if(employeeId){
            return <h2 className='text-center'>Update Employee</h2>
        }else{
            return <h2 className='text-center'>Add Employee</h2>
        }
    }

    return(
        <div>
            <br></br>
            <div className='container'>
            <div className='row'>
                <div className='card col-md-6 offset-md-3 offset-md-3'>
                    {
                        title()
                    }
                    <div className='card-body'>
                        <form>
                            <div className='form-group mb-2'>
                                <label className='form-label'>Employee Id</label>
                                <input type="text" placeholder='Please enter Id' name='empId' className='form-control' value={empId} onChange={(e)=> setEmpId(e.target.value)}></input>
                            </div>

                            <div className='form-group mb-2'>
                                <label className='form-label'>Employee Name</label>
                                <input type="text" placeholder='Please enter name' name='empName' className='form-control' value={empName} onChange={(e)=> setEmpName(e.target.value)}></input>
                            </div>

                            <div className='form-group mb-2'>
                                <label className='form-label'>Employee Address</label>
                                <input type="text" placeholder='Please enter address' name='empAddress' className='form-control' value={empAddress} onChange={(e)=> setEmpAddress(e.target.value)}></input>
                            </div>

                            <div className='form-group mb-2'>
                                <label className='form-label'>Employee Contact Number</label>
                                <input type="text" placeholder='Please enter contact number' name='empContactNumber' className='form-control' value={empContactNumber} onChange={(e)=> setEmpContactNumber(e.target.value)}></input>
                            </div>


                            <div className='form-group mb-2'>
                                <label className='form-label'>Employee Salary</label>
                                <input type="text" placeholder='Please enter salary' name='empSalary' className='form-control' value={empSalary} onChange={(e)=> setEmpSalary(e.target.value)}></input>
                            </div>

                            <div className='form-group mb-2'>
                                <label className='form-label'>Employee DOB</label>
                                <input type="text" placeholder='Please enter DOB' name='empDOB' className='form-control' value={empDOB} onChange={(e)=> setEmpDOB(e.target.value)}></input>
                            </div>

                            <div className='form-group mb-2'>
                                <label className='form-label'>Employee Email Id</label>
                                <input type="text" placeholder='Please enter email id' name='empEmailId' className='form-control' value={empEmailId} onChange={(e)=> setEmpEmailId(e.target.value)}></input>
                            </div>

                            <div className='form-group mb-2'>
                                <label className='form-label'>Employee Password</label>
                                <input type="password" placeholder='Please enter Password' name='empPassword' className='form-control' value={empPassword} onChange={(e)=> setEmpPassword(e.target.value)}></input>
                            </div>

                            <button className='btn btn-success' onClick={(e)=> saveOrUpdateEmployee(e)}>Submit</button>

                            <Link to='/employees' className='btn btn-danger'>Cancel</Link>


                        </form>
                    </div>

                </div>
            </div>
        </div>

        </div>
    )


}

export default AddEmployeeComponent;