import React from 'react';

const FooterComponent = ()=>{
    return(
        <div>
            <footer className='text-center'>
                <span className='text-muted'>All Rights Reserved by Fintech CSI PUNE @2022</span>
            </footer>
        </div>
    )
}

export default FooterComponent;