import axios from 'axios';


const HRM_BASE_URL='http://localhost:8080/employees';

class EmployeeService{

    getAllEmployees(){
        return axios.get(HRM_BASE_URL +'/');
    }

    createEmployee(employee){
        return axios.post(HRM_BASE_URL +'/', employee);
    }

    getEmployeeById(employeeId){
        return axios.get(HRM_BASE_URL+'/', employeeId);
    }

    updateEmployee(employeeId, employee){
        return axios.put(HRM_BASE_URL+'/'+employeeId, employee);
    }

    deleteEmployee(employeeId){
        return axios.delete(HRM_BASE_URL+'/'+employeeId);
    }

}

export default new EmployeeService();